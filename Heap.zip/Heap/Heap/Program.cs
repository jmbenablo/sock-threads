﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Heap
{
    class Program
    {
        static void insertNode(Heap h, int item)
        {


            if(Convert.ToBoolean(h.insert(item) + 1))
            {
                Console.WriteLine("\tSuccessfully inserted node with value " + item);
            }
            else
            {
                Console.WriteLine("\tError:Insert node unsuccessful.");
            }
        }

        static void deleteNode(Heap h, int item)
        {
            int max = h.maximum();

            if(h.remove(item) + 1 > 0)
            {
                Console.WriteLine("Successfully deleted node with value " + max );
            }
            else
            {
                Console.WriteLine("\tError: Heap is empty");
            }
        }


        static void Main(string[] args)
        {
            string prompt;
            Heap h = new Heap(99);
            int item = -1;
            //String[] p_prompt;
            /*h.insert(8);
            h.levelOrder();
            h.insert(14);

            h.levelOrder();
            h.insert(10);

            h.levelOrder();
            h.insert(16);

            h.levelOrder();
            h.insert(15);

            h.levelOrder();*/


            do
            {
                Console.Write("prompt>");
                prompt = Console.ReadLine();
                string[] p_prompt = prompt.Split(' ');


                try
                {
                    item = Convert.ToInt32(p_prompt[1]);

                }
                catch (System.FormatException)
                {
                    if (prompt.Contains("rm") || prompt.Contains("ins"))
                    {
                        Console.WriteLine("\tError: invalid parameter");
                    }
                    else
                    {
                        Console.WriteLine("\tError: invalid command");
                    }

                }
                catch (System.IndexOutOfRangeException)
                {
                    if (prompt.Contains("rm") || prompt.Contains("ins")) //baba yung rm later ok pag naverify na
                    {
                        Console.WriteLine("\tError: invalid parameter");
                        item = -1;


                    }
                    else if (prompt.Length == 0 || prompt.Contains("levelo") || prompt.Contains("bye"))
                    {

                    }
                    else
                    {
                        Console.WriteLine("\tError: invalid command");
                        item = -1;
                    }


                }

                if (item >= 0)
                { 
                    switch (p_prompt[0])
                    {
                        case "ins":
                            //Console.Write("whoa");
                            insertNode(h, item);
                            break;
                        case "rm":
                            deleteNode(h, item);
                            break;
                        case "levelo":
                            h.levelOrder();
                            break;
                        default:
                            break;


                    }
                }


            } while (!prompt.Equals("bye"));


        }
    }
}
