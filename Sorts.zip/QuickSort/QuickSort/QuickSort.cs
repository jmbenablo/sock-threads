﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuickSort
{
    class QuickSort
    {
        private int Partition(int[] arr, int left, int right)
        {
            int pivot = arr[left];

            while (true)
            {
                while (arr[left] < pivot)
                    left++;
                
                while (arr[right] > pivot)
                    right--;  
                
                if (left < right)
                {
                    int temp = arr[right];

                    arr[right] = arr[left];
                    arr[left] = temp;
                }
                else
                {
                    return right;
                }
            }
        }


        public int[] sort(int[] arr, int left, int right)
        {

            // For Recusrion 
            if (left < right)
            {

                int pivot = Partition(arr, left, right);

                if (pivot > 1)
                    sort(arr, left, pivot - 1);

                if (pivot + 1 < right)
                    sort(arr, pivot + 1, right);

            }
            else
            {
               
            }
            return arr;
        }
    }
}
