﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuickSort
{
    class Program
    {        
        private static int MAX_SIZE = 10;

        static void printContents(int[] sorted)
        {
            int i;

            Console.Write("\nSorted Values: ");

            for (i = 0; i < MAX_SIZE; i++)
            {
                Console.Write(sorted[i] + " ");
            }
        }

        static void Main(string[] args)
        {
            int i = 0, input;

            int[] arr = new int[MAX_SIZE];
            QuickSort q_sort = new QuickSort();

            Console.WriteLine("Quick Sort Algorithm");

            while (i < MAX_SIZE)
            {
                try
                {
                    Console.Write("input " + (i + 1) + ": ");
                    input = Convert.ToInt32(Console.ReadLine());

                    arr[i] = input;
                    i++;
                }
                catch
                {
                    Console.WriteLine("\tError: Invalid user input");
                }
            }

            if (i == MAX_SIZE)
            {
                arr = q_sort.sort(arr, 0, MAX_SIZE - 1);
                printContents(arr);
            }
            else
            {

            }

            Console.ReadKey();
        }
        
    }
}
