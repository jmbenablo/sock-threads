﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HeapSort
{
    class Heap
    {
        private int[] heap;
        private int arrSize;
        private int count;
        private int UNSUCCESSFUL = -1;

        public Heap()
        {
            count = 0;
            arrSize = 0;
            heap = new int[arrSize];
        }

        public Heap(int size)
        {
            count = 0;
            arrSize = size;
            heap = new int[arrSize];

        }

        private void swap(int pos1, int pos2)
        {
            int temp;

            temp = heap[pos1];
            heap[pos1] = heap[pos2];
            heap[pos2] = temp;
        }

        private void heapifyUp()
        {
            int i;


            for (i = count; i > 1; i = i / 2)
            {
                //Console.Write("--->");
                //levelOrder();
                if (heap[i] > heap[i / 2]) // if current node > parent node
                {
                    swap(i, i / 2); // i -> i/2
                    /*
                    temp = heap[i];
                    heap[i] = heap[i / 2];
                    heap[i / 2] = temp;*/
                }
                else
                {

                }
            }
        }

        private void heapifyDown()
        {
            int i = 1; //root node 
            int leftChild;
            int rightChild;


            while (i < count)
            {
                leftChild = 2 * i;
                rightChild = 2 * i + 1;

                if (leftChild < count && rightChild <= count) // has two children
                {
                    if (heap[leftChild] >= heap[rightChild] && heap[leftChild] > heap[i]) // if left child is higher than parent
                    {
                        swap(leftChild, i);
                        i = leftChild;
                    }
                    else if (heap[rightChild] > heap[i]) // if right child is higher than parent
                    {
                        swap(rightChild, i);
                        i = rightChild;
                    }
                    else
                    {
                        break;
                    }
                }
                else if (rightChild > count && leftChild <= count) // has only left child
                {
                    if (heap[leftChild] > heap[i])
                    {
                        swap(leftChild, i);
                        i = leftChild;
                    }
                    else
                    {
                        break;
                    }
                }
                else // leaf node
                {
                    break;
                }

            }
        }

        public int size()
        {
            return this.count;
        }

        public int insert(int item_i)
        {
            if (count < arrSize && item_i >= 0)
            {
                count++;
                heap[count] = item_i;
                heapifyUp();

                return 0;
            }
            else
            {
                return UNSUCCESSFUL;
            }
        }

        /* NORMAL MAX HEAP DELETE */
        public int remove()
        {

            if (count > 0)
            {
                /*temp = heap[count];
                heap[count] = heap[1];
                heap[1] = temp;*/
                swap(count, 1);
                count--;

                heapifyDown();

                return 0;
            }
            else
            {
                return UNSUCCESSFUL;
            }
        }

        public int maximum()
        {
            if (count > 0)
            {
                return heap[1];
            }
            else
            {
                return UNSUCCESSFUL;
            }
        }


        public void levelOrder()
        {
            int i;

            if (count > 0)
            {
                Console.WriteLine("Level Order Traversal");
                for (i = 1; i <= count; i++)
                {
                    Console.Write(heap[i] + " ");
                }

                Console.WriteLine();
            }
            else
            {
                Console.WriteLine("Heap is empty.");
            }
        }
    }
}
