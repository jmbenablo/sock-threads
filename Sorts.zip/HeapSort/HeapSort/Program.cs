﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HeapSort
{
    class Program
    {
        private static int MAX_SIZE = 10;

        static int[] HeapSort(Heap h)
        {
            int i;
            int[] arr = new int[MAX_SIZE];
            

            for (i = MAX_SIZE - 1; i >= 0; i--)
            {
                arr[i] = h.maximum();
                h.remove();
            }

            return arr;

        }

        static void printContents(int[] sorted)
        {
            int i;

            Console.Write("\nSorted Values: ");

            for (i = 0; i < MAX_SIZE; i++)
            {
                Console.Write(sorted[i] + " ");
            }
        }

        static void Main(string[] args)
        {
            int i = 0, input;
            
            Heap heap = new Heap(10);

            Console.WriteLine("Heap Sort Algorithm");

            while (i < MAX_SIZE)
            {
                try
                {
                    Console.Write("input " + (i + 1)+ ": ");
                    input = Convert.ToInt32(Console.ReadLine());

                    heap.insert(input);
                    i++;
                }
                catch
                {
                    Console.WriteLine("\tError: Invalid user input");
                }
            }

            if (i == MAX_SIZE)
            {
                int[] arr = HeapSort(heap);
                printContents(arr);
            }
            else
            {

            }

            Console.ReadKey();
        }
    }
}
